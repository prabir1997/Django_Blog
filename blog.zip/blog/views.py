from django.shortcuts import render

# Create your views here.
from django.views.generic import ListView,CreateView,DetailView, UpdateView, DeleteView # new
from .models import Post
from .forms import PostForm
from django.urls import reverse_lazy


class HomePageView(ListView):
    model= Post
    template_name = 'base.html'
    
class BlogDetailView(DetailView): # new
    model = Post
    template_name = 'post_detail.html'

class CreatePostView(CreateView):
    model= Post
    form_class = PostForm
    template_name = 'post.html'
    success_url = reverse_lazy("home")

class BlogUpdateView(UpdateView): # new
    model = Post
    template_name = 'post_edit.html'
    fields = ['title', 'cover']
    
class BlogDeleteView(DeleteView): # new
    model = Post
    template_name = 'post_delete.html'
    success_url = reverse_lazy('home')
