from django.db import models
from django.urls import reverse #

# Create your models here.
class Post(models.Model):
    title = models.TextField(max_length=100)
    cover = models.ImageField(upload_to='images/')
    
    def __str__(self):
        return self.title
    
    def get_absolute_url(self): # new
        return reverse('post_detail', args=[str(self.id)])

    
    

